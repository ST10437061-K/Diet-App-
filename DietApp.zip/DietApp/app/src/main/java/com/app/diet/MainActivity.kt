package com.app.diet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etSurname = findViewById<EditText>(R.id.etSurname).text
        val etEmailAddress = findViewById<EditText>(R.id.etEmail).text
        val etPhoneNumber = findViewById<EditText>(R.id.etPhoneNumber).text
        val etDay = findViewById<EditText>(R.id.etDay).text

        val btnDisplay = findViewById<Button>(R.id.btnDisplay)

        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnDisplay.setOnClickListener {

            var message: String = ""

            when (etDay.toString()) {
                "Monday" -> message = "For ${etDay.toString()} : Grilled chicken with quinoa salad"
                "Tuesday" -> message = "For ${etDay.toString()} : Salmon with steamed vegetables"
                "Wednesday" -> message = "For ${etDay.toString()} : Vegetable stir-fry with tofu"
                "Thursday" -> message = "For ${etDay.toString()} : Turkey and avocado wrap"
                "Friday" -> message = "For ${etDay.toString()} : Grilled fish tacos with salsa"
                "Saturday" -> message = "For ${etDay.toString()} : Whole wheat pasta with marinara sauce"
                "Sunday" -> message = "For ${etDay.toString()} : Roast beef with roasted potatoes and vegetables"
                else -> message = "Invalid day"
            }

            tvResult.text = "Hi ${etSurname}, ${message} \n" +
                    "This suggestion will be emailed to ${etEmailAddress} \n" +
                    "And our dietitian will call you on ${etPhoneNumber}"
        }
    }
}